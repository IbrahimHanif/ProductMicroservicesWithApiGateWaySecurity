Insert into products(id,product_name, price) values 
(101,'Chair', 2000);
Insert into products(id,product_name, price) values 
(102,'Table',10000);
Insert into products(id,product_name, price) values 
(103,'Ladder', 3000);
Insert into products(id,product_name, price) values 
(104,'Bed', 20000);
Insert into products(id,product_name, price) values 
(105,'cupboard', 15000);


Insert into orders(id,user_name,product_name, quantity,totalcost,orderdate) 
values 
(101,'Ibrahim','chair',2, 4000,'05/17/2020 12:26:18');
